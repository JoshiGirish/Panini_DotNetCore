﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Panini.ViewModel
{
    /// <summary>
    /// Manages the behavior of <c>About View</c>.
    /// </summary>
    public class AboutViewModel : BaseViewModel
    {
    }
}
