﻿using System.Windows.Controls;
using Panini.ViewModel;

namespace Panini.Pages
{
    /// <summary>
    /// Interaction logic for ResultsPage.xaml
    /// </summary>
    public partial class ResultsPage : Page
    {
        public ResultsPage()
        {
            InitializeComponent();
        }
    }
}
